from a_3_1_2 import UI
import os

#c와 b와 a_3_1_2세트


def main():
    d = UI()
    d.all()
    

if __name__ == "__main__":
    main()
